from django.contrib import admin
from .models import Initi,  Goals, Reports, Supports, Stages, MainStage, Risks,  Challenges, Comment


# Register your models here.
admin.site.register(Initi)
admin.site.register(Goals)
admin.site.register(Reports)
admin.site.register(Supports)
admin.site.register(Stages)
admin.site.register(MainStage)
admin.site.register(Risks)
admin.site.register(Challenges)
admin.site.register(Comment)

